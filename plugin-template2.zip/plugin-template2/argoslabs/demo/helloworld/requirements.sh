#!/usr/bin/env bash

# pip dependent packages
uv pip install -r requirements.txt \
    --extra-index-url https://pypi-official.argos-labs.com/simple \
    --index-strategy unsafe-best-match
