# argoslabs.demo.helloworld

***Description of this plugin***

> Note: ...

## Name of the plugin
Item | Value
---|:---:
Icon | ![Plugin Name](icon.png) 
Display Name | **Plugin Name**

## Name of the author (Contact info of the author)

Your Name
* [email](mailto:name@your.com)
* [github](https://github.com/your)

## Notification

### Dependent modules
Module | Source Page | License | Version (If specified otherwise using recent version will be used)
---|---|---|---
[dep-module]() | [dep-module]() | [MIT](https://github.com/ssut/py-googletrans/blob/master/LICENSE) | 4.0

> * Note

## Warning 
No potential damage to customer files and data (overwrite risk)

## Helpful links to 3rd party contents
None

## Version Control 
* [26.108.1000](setup.yaml)
* Release Date: `Jan 8, 2026`

## Input (Required)
Display Name | Input Method | Default Value | Description
---|---|---|---
msg | | | message to translate

> * Note

## Input (Optional)

Display Name | Show Default | Input Method | Default Value | Description
---|---|---|---|---
Text file | True | fileread | | Text file to read message
File Encoding | False | | utf8 | File encoding for text file
Target lang | True | choices | English | Destination language to use

> * Note

## Return Value

### Normal Case
Description of output result

## Return Code
Code | Meaning
---|---
0 | Success
99 | Exceptional case

## Parameter setting examples (diagrams)
If any STU example capture images.